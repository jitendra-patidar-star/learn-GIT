<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_Provider_Model extends CI_Model {

   	public function __construct()
	{
		parent::__construct();
	}
	
	public function service_provider_insert($data)
	{
	    $this->db->insert('Service_Provider',$data);
	}
	
	public function service_provider_auth_data($email,$password)
	{
	 
	 $q =  $this->db->select('Email,Phone,Password')
	                ->from('Service_Provider')
	                ->where(array('Email'=>$email,'Password'=>md5($password)))
	                ->get();
	 return $q;
	}
	
	public function service_provider_auth_data_with_phone($phone,$password)
	{
	 
	 $q =  $this->db->select('Email,Phone,Password')
	                ->from('Service_Provider')
	                ->where(array('Phone'=>$phone,'Password'=>md5($password)))
	                ->get();
	 return $q;
	}
	
	public function insert_reset_token($email,$phone,$resettoken)
	{
	    $resetdata = array('ResetPasswordToken',$resettoken);
	    
	    $q =   $this->db->where(array('Email'=>$email))
	                    ->or_where('Phone',$phone)
	                    ->update('Service_Provider',$resetdata);
	}
	
	public function reset_password_data($data , $serviceproviderid)
	{
	    $newdata = array('Password'=>$data['password']);
	    $q =   $this->db->where(array('ResetPasswordToken'=>$data['ResetPasswordToken'],'ServiceProviderID'=>$serviceproviderid))
	                    ->update('Service_Provider',$newdata);
	   return true;
	}
	
	public function get_service_provider_data_by_id($serviceproviderid)
	{
            $q = $this->db->select('*')
                         ->from('Service_Provider')
                         ->where('ServiceProviderID',$serviceproviderid)
                         ->get();
                         
            return $q->result_array();
	}
	
	public function service_provider_update_setting( $data , $serviceproviderid )
	{
	   $q = $this->db->where('ServiceProviderID',$serviceproviderid)
	                 ->update('Service_Provider',$data);
	   return $q;
	}
	
}