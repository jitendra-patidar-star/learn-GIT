<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_Main_Model extends CI_Model {

   	public function __construct()
	{
		parent::__construct();
	}
	
	public function issue_RFQ_insert()
	{
	    
	}
}
	