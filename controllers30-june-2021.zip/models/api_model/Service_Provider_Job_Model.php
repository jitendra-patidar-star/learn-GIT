<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_Provider_Job_Model extends CI_Model {

   	public function __construct()
	{
		parent::__construct();
	}
	
	public function job_data_for_service_provider_data()
	{
	    
	 $q =  $this->db->select('*')
	                ->from('Job')
	                ->get();
	           
	 return $q->result_array();

	}
}