<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_model extends CI_Model {

   	public function __construct()
	{
		parent::__construct();
	}
	
	public function member_insert($data)
	{
	    $this->db->insert('Member',$data);
	}
	
	public function member_auth_data($email,$password)
	{
	 
	 $q =  $this->db->select('Email,Phone,Password')
	                ->from('Member')
	                ->where(array('Email'=>$email,'Password'=>md5($password)))
	                ->get();
	 return $q;
	}
	
	public function member_auth_data_with_phone($phone,$password)
	{
	 
	 $q =  $this->db->select('Email,Phone,Password')
	                ->from('Member')
	                ->where(array('Phone'=>$phone,'Password'=>md5($password)))
	                ->get();
	 return $q;
	}
	
	public function insert_reset_token($email,$phone,$resettoken)
	{
	    $resetdata = array('ResetPasswordToken',$resettoken);
	    $q =   $this->db->where(array('Email'=>$email))
	                    ->or_where('Phone',$phone)
	                    ->update('Member',$resetdata);
	}
	
	public function reset_password_data($data,$memberid)
	{
	    $newdata = array('Password'=>$data['password']);
	    $q =   $this->db->where(array('ResetPasswordToken'=>$data['ResetPasswordToken'],'MemberID'=>$memberid))
	                    ->update('Member',$newdata);
	   return true;
	}
	
	public function get_member_data_by_id($memberid)
	{
            $q = $this->db->select('*')
                         ->from('Member')
                         ->where('MemberID',$memberid)
                         ->get();
                         
            return $q->result_array();
	}
	
	public function member_update_setting( $data , $memberid )
	{
	   $q = $this->db->where('MemberID',$memberid)
	                 ->update('Member',$data);
	   return $q;
	}
	
}