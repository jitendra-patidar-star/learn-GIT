<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_Job_Model extends CI_Model {

   	public function __construct()
	{
		parent::__construct();
	}
	
	public function get_service_provider_profile($ServiceProviderID)
	{
    	$q =   $this->db->select('*')
    	             ->from('Service_Provider')
    	             ->where('ServiceProviderID',$ServiceProviderID)
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	public function get_job_data()
	{
	    $q =   $this->db->select('*')
    	             ->from('Job')
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	public function get_new_responded_job_data()
	{
	     $q =   $this->db->select('*')
    	             ->from('Job')
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	public function get_confirmed_job_data()
	{
	     $q =   $this->db->select('*')
    	             ->from('Job')
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	public function list_services_data_job()
	{
	     $q =   $this->db->select('*')
    	             ->from('Job')
    	             ->join('Job_Provider','Job_Provider.JobID = Job.JobID')
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	public function list_completed_job_data()
	{
	    
	     $q =   $this->db->select('*')
    	             ->from('Job')
    	             ->join('Job_Provider','Job_Provider.JobID = Job.JobID')
    	             ->where('AcceptRFQ !=','')
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	public function get_closed_jobs()
	{
	     $q =   $this->db->select('*')
    	             ->from('Job')
    	             ->join('Job_Provider','Job_Provider.JobID = Job.JobID')
    	             ->where('AcceptRFQ !=','')
    	             ->get();
    	             
    	 return $q->result_array();
	}
	
	
}