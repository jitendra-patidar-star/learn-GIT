<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_Provider_Job extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	    $this->load->model('api_model/Service_Provider_Job_Model');

    }
    
    public function get_all_job_service_provider()
    {
       $data = $this->Service_Provider_Job_Model->job_data_for_service_provider_data();
       
       echo json_encode($data);
    }
    
}