<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_Service_list extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	    $this->load->model('api_model/Member_Service_list_Model');

    }
    
    public function get_services_from_one_to_six_data()
	{
	    
	    $servicetype =  $this->Member_Service_list_Model->get_services_type_from_one_to_six();
	    echo json_encode($servicetype);
	  
	}
	
	public function get_services_from_one_to_twele_data()
	{
	    
	    $servicetype =  $this->Member_Service_list_Model->get_services_from_one_to_twele();
	    echo json_encode($servicetype);
	  
	}
	
	public function get_serices_by_service_type($servicetypeid)
	{
	    $service =  $this->Member_Service_list_Model->get_services_by_type_id($servicetypeid);  
	    echo json_encode($service);
	}
	
	public function get_serivce_description($serviceid)
	{
	    $servicedesc =  $this->Member_Service_list_Model->get_serivce_description_data($serviceid);  
	    echo json_encode($servicedesc);
	}
}