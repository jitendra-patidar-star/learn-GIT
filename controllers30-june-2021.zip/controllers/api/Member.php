<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	    $this->load->model('api_model/member_model');

    }
    
    public function member_register()
    {
        
        $inputdata= $this->input->post();
        $inputdata['CreditScore'] = '100' ;
        $inputdata['Validtill']= '2029/12/31' ;
        $inputdata['English']= $this->input->post('English');;
        $inputdata['TChinese']= $this->input->post('TChinese'); ;
        $inputdata['SChinese']= $this->input->post('SChinese'); ;
        
        
        if($inputdata['FirstName'] || $inputdata['LastName'] || $inputdata['Phone'] || $inputdata['Email'] ||$inputdata['Retype_Email'] || $inputdata['Password'] || $inputdata['Retype_Password'] || $inputdata['PostCode'])
        {
            $msg = array('status'=>'Failed','msg'=>'Please Fill All Required Fileds');
            echo json_encode($msg);
            
        }
        elseif($inputdata['Email'] != $inputdata['Retype_Email'])
        {
            $msg = array('status'=>'Failed','msg'=>'Email Not Macth');
            echo json_encode($msg);
            
        }
        elseif($inputdata['Password'] != $inputdata['Retype_Password'])
        {
            
            $msg = array('status'=>'Failed','msg'=>'Password Not Macth');
            echo json_encode($msg);
            
        }
        else
        {
            $inputdata['Password'] = md5($inputdata['Password']);
           
            $insert =  $this->member_model->member_insert($inputdata);
            
            if($insert){
                 
                $msg = array('status'=>'Success','msg'=>'Registerd Successfully');
                echo json_encode($msg);
                
            }else{
                
                $msg = array('status'=>'Failed','msg'=>'Error!!');
                echo json_encode($msg);
            }
          
            
        }
        
    }
    
    public function member_auth()
    {
        $email    = $this->input->post('email');
        $password = $this->input->post('password');
        $phone = $this->input->post('phone');
        
        if($email !='' || $password!=''){
            
            $auth =  $this->member_model->member_auth_data( $email , $password );  
        
                if($auth->num_rows() > 0){
                     
                        $logindata  = $auth->row_array();
                        $userid=     $logindata['MemberID'];
                        $email = $logindata['Email'];
                        
                        //$sesdata = array('id'=>$id,'email'=> $email,'logged_in' => TRUE);
                        //$this->session->set_userdata($sesdata);
                        //redirect('Admin/dashboard');
        	        
        	        $datas = array('status'=>'Success','msg'=>'Login Successfully','user_id'=>$userid);
                    echo json_encode($datas);
                   
        	    }else{
        	        
        	        $datas = array('status'=>'Failed','msg'=>'Invalid Login Details!!');
                    echo json_encode($datas);
                    
        	    }
            
        }elseif($phone !='' || $password!=''){
            
            $auth =  $this->member_model->member_auth_data_with_phone( $phone , $password );  
        
                if($auth->num_rows() > 0){
                     
                        $logindata  = $auth->row_array();
                        $userid=     $logindata['MemberID'];
                        $phone = $logindata['Phone'];
                        
                        //$sesdata = array('id'=>$id,'email'=> $email,'logged_in' => TRUE);
                        //$this->session->set_userdata($sesdata);
                        //redirect('Admin/dashboard');
        	        
        	        $datas = array('status'=>'Success','msg'=>'Login Successfully','user_id'=>$userid);
                    echo json_encode($datas);
                   
        	    }else{
        	        
        	        $datas = array('status'=>'Failed','msg'=>'Invalid Login Details!!');
                    echo json_encode($datas);
                    
        	    }
        	    
        }else{
            
            $datas = array('status'=>'Failed','msg'=>'Please Fill Both Fileds');
            echo json_encode($datas);
        }
      
      
    }
    
    public function reset_password_token()
    {
        
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        
        $length = 8;
        $str = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
        $resettoken = substr(str_shuffle($str), 0, $length);
        
        $tokeninsert = $this->member_model->insert_reset_token($email,$phone,$resettoken);
        
        $sendmail = $this->send_email_for_reset_token($email,$resettoken);
        $sendmsg = $this->send_msg_for_reset_token($email,$resettoken);
        
        if($tokeninsert || $sendmail || $sendmsg){
            
            $datas = array('status'=>'Success','msg'=>'Token Generated Successfully');
            echo json_encode($datas);
            
        }else{
            
            $datas = array('status'=>'Failed','msg'=>'Error In Generating Token');
            echo json_encode($datas);
        }
        
       /* if($email != ''){
            
            $length = 8;
            $str = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
              
            $resettoken = substr(str_shuffle($str), 0, $length);
            
            $this->member_model->insert_reset_token($email,$resettoken);

        }elseif($phone != ''){
            
            $length = 8;
            $str = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
              
            $resettoken = substr(str_shuffle($str), 0, $length);
            
            $this->member_model->insert_reset_token($email,$resettoken);
            
        }*/
        
    }
    
    public function send_email_for_reset_token($email,$resettoken)
    {
        
        $from ="info@qwickhand.com";
        $to = "ayushi.goyal@reflom.com";
        $subject = "Password Reset Token";
        $message = "Hello .'$email'.";
        
        $msg = '
            <p>Hello '.$email.' ,</p>
            <h3>Please find your Reset Password Token.</h3>
            <p><b>Token: </b>'.$resettoken.'</p>
            <p>Copy the below code and go back to the link and put this code</p>
            <p><b>Date of Enquiry:</b> '. date("d-M-Y").
            '<br>
            
            <h4><i>Thanks & Regards,</i></h4>
            <p>Qwick Hand</p>'
            ;

        $config['mailtype'] = 'html';
        $this->email->set_newline("\r\n");
        $this->email->set_header('MIME-Version', '1.0; charset=utf-8'); //must add this line
        $this->email->set_header('Content-type', 'text/html'); //must add this line
        $this->email->initialize($config);
        $this->email->from('info@qwickhand.com',"Qwickhand"); //your mail address
        $this->email->to($email); //customer mail address
        $this->email->subject($subject);
        $this->email->message($message);
        $res = $this->email->send();

        return $res;

       
    }
    
    public function send_msg_for_reset_token($phone , $resettoken)
    {
          
//	$apiKey = urlencode('lwHg4/unmNs-sDzGCNZxhebNp1mYexD7ApS1JdtnFV');
    $apiKey ="";
	// Message details
	$numbers = array("91".$phone);
	$sender = urlencode('QWICKIND');
	$message = rawurlencode("Your reset password token is '.$resettoken.' ");
 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
    }
    
    
    public function reset_password($memberid)
    {
        
        $inputdata = $this->input->post();
        
        if($inputdata['reset_token'] =='' || $inputdata['password'] =='' || $inputdata['confirm_password'] =='')
        {
            $datas = array('status'=>'Failed','msg'=>'Please Fill All Required Field');
            echo json_encode($datas);
        }
        else{
            
            $resetpassword = $this->member_model->reset_password_data($inputdata,$memberid);
            
            if($resetpassword){
                
                 $datas = array('status'=>'Success','msg'=>'Password Reset Successfully');
                 echo json_encode($datas);
                
            }else{
                
                 $datas = array('status'=>'Failed','msg'=>'Error!!');
                 echo json_encode($datas);
            }
           
        }
        
    }
    
    public function get_member_setting_data($memberid)
    {
        $meberdata = $this->member_model->get_member_data_by_id($memberid);
        
        echo json_encode($meberdata);
    }
    
    public function member_data_update()
    {
        $inputdata = $this->input->post();
        
        $inputdata['English']= $this->input->post('English');;
        $inputdata['TChinese']= $this->input->post('TChinese'); ;
        $inputdata['SChinese']= $this->input->post('SChinese'); ;
        
        
        if($inputdata['FirstName'] || $inputdata['LastName'] || $inputdata['Phone'] || $inputdata['Email'] ||$inputdata['Retype_Email'] || $inputdata['Password'] || $inputdata['Retype_Password'] || $inputdata['PostCode'])
        {
            $msg = array('status'=>'Failed','msg'=>'Please Fill All Required Fileds');
            echo json_encode($msg);
            
        }
        elseif($inputdata['Email'] != $inputdata['Retype_Email'])
        {
            $msg = array('status'=>'Failed','msg'=>'Email Not Macth');
            echo json_encode($msg);
            
        }
        elseif($inputdata['Password'] != $inputdata['Retype_Password'])
        {
            
            $msg = array('status'=>'Failed','msg'=>'Password Not Macth');
            echo json_encode($msg);
            
        }
        else
        {
            $inputdata['Password'] = md5($inputdata['Password']);
           
            $update =  $this->member_model->member_update_setting($inputdata);

            if($update){
                
                $msg = array('status'=>'Success','msg'=>'Updated Successfully');
                echo json_encode($msg);
            
                
            }else{
                
                $msg = array('status'=>'Failed','msg'=>'Error!!');
                echo json_encode($msg);
            
            }          
           
            
        }
    }
}