<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_Job extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	    $this->load->model('api_model/Member_Job_Model');

    }
    
    public function service_provider_profile()
    {
        $serviceproviderdata =   $this->Member_Job_Model->get_service_provider_profile($ServiceProviderID);
        
        echo json_encode($serviceproviderdata);
    }
    
    public function get_all_job()
    {
        
        $jobdata =   $this->Member_Job_Model->get_job_data();
        
        echo json_encode($jobdata);
    }
    
    public function get_new_responded_job()
    {
        $jobdata =   $this->Member_Job_Model->get_new_responded_job_data();
        
        echo json_encode($jobdata);
    }
    
    public function get_confirmed_job()
    {
        $jobdata =   $this->Member_Job_Model->get_confirmed_job_data();
        
        echo json_encode($jobdata);
    }
    
    public function list_service_provider()
    {
        $jobdata =   $this->Member_Job_Model->list_services_data_job();
        
        echo json_encode($jobdata);
    }
    
    public function list_completed_job()
    {
        $jobdata =   $this->Member_Job_Model->list_completed_job_data();
        
        echo json_encode($jobdata);
    }
    
    public function closed_jobs()
    {
        $jobdata =   $this->Member_Job_Model->get_closed_jobs();
        
        echo json_encode($jobdata);
    }
    
}