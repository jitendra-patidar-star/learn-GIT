
    <!-- Right Slidebar start -->
      <div class="sb-slidebar sb-right sb-style-overlay">
          <h5 class="side-title">Online Customers</h5>
          <ul class="quick-chat-list">
              <li class="online">
                  <div class="media">
                      <a href="#" class="">
                          <img alt="" src="img/chat-avatar2.jpg" class="mr-3 rounded-circle">
                      </a>
                      <div class="media-body">
                          <strong>John Doe</strong>
                          <small>Dream Land, AU</small>
                      </div>
                  </div><!-- media -->
              </li>
              <li class="online">
                  <div class="media">
                      <a href="#" class="">
                          <img alt="" src="img/chat-avatar.jpg" class="mr-3 rounded-circle">
                      </a>
                      <div class="media-body">
                          <div class="media-status">
                              <span class=" badge bg-important">3</span>
                          </div>
                          <strong>Jonathan Smith</strong>
                          <small>United States</small>
                      </div>
                  </div><!-- media -->
              </li>

              <li class="online">
                  <div class="media">
                      <a href="#" class="">
                          <img alt="" src="img/pro-ac-1.png" class="mr-3 rounded-circle">
                      </a>
                      <div class="media-body">
                          <div class="media-status">
                              <span class=" badge badge-success">5</span>
                          </div>
                          <strong>Jane Doe</strong>
                          <small>ABC, USA</small>
                      </div>
                  </div><!-- media -->
              </li>
              <li class="online">
                  <div class="media">
                      <a href="#" class="">
                          <img alt="" src="img/avatar1.jpg" class="mr-3 rounded-circle">
                      </a>
                      <div class="media-body">
                          <strong>Anjelina Joli</strong>
                          <small>Fockland, UK</small>
                      </div>
                  </div><!-- media -->
              </li>
              <li class="online">
                  <div class="media">
                      <a href="#" class="">
                          <img alt="" src="img/mail-avatar.jpg" class="mr-3 rounded-circle">
                      </a>
                      <div class="media-body">
                          <div class="media-status">
                              <span class=" badge bg-warning">7</span>
                          </div>
                          <strong>Mr Tasi</strong>
                          <small>Dream Land, USA</small>
                      </div>
                  </div><!-- media -->
              </li>
          </ul>
          <h5 class="side-title"> pending Task</h5>
          <ul class="p-task tasks-bar">
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Dashboard v1.3</div>
                          <div class="percent">40%</div>
                      </div>
                      <div class="progress">
                          <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-striped bg-success">
                              <span class="sr-only">40% Complete (success)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Database Update</div>
                          <div class="percent">60%</div>
                      </div>
                      <div class="progress">
                          <div style="width: 60%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="60" role="progressbar" class="progress-bar progress-bar-striped bg-warning">
                              <span class="sr-only">60% Complete (warning)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Iphone Development</div>
                          <div class="percent">87%</div>
                      </div>
                      <div class="progress">
                          <div style="width: 87%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="20" role="progressbar" class="progress-bar progress-bar-striped bg-info">
                              <span class="sr-only">87% Complete</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Mobile App</div>
                          <div class="percent">33%</div>
                      </div>
                      <div class="progress">
                          <div style="width: 33%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="80" role="progressbar" class="progress-bar progress-bar-striped bg-danger">
                              <span class="sr-only">33% Complete (danger)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Dashboard v1.3</div>
                          <div class="percent">45%</div>
                      </div>
                      <div class="progress">
                          <div style="width: 45%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="45" role="progressbar" class="progress-bar progress-bar-striped">
                              <span class="sr-only">45% Complete</span>
                          </div>
                      </div>

                  </a>
              </li>
              <li class="external">
                  <a href="#">See All Tasks</a>
              </li>
          </ul>
      </div>
      <!-- Right Slidebar end -->
    
      <!--footer start-->
     <!-- <footer class="site-footer">
          <div class="text-center " style="color:white;font-size:15px;">
              2020 &copy; Exam Module
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>-->
      <div class="row exammodule-footer">
            <div class="col-md-3"></div>
              <div class="col-md-4"> 
              <p class="text-center " style="margin-bottom: 0px;text-align:center;">© <span id="copyrightyear">2021</span>  <b><a href="#" style="text-decoration: none;color:white;" target="_blank">Qwickhand</a></b></p>
          </div>
          <div class="col-md-5"></div>
      </div>
      <!--footer end-->

   </section>
   </section>
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
   <script>
        $(function(){
    var url = window.location.pathname, 
    urlRegExp = new RegExp(url.replace(/\/$/,'') + "$"); // create regexp to match current url pathname and remove trailing slash if present as it could collide with the link in navigation in case trailing slash wasn't present there
        // now grab every link from the navigation
          console.log(urlRegExp);
        $('li a').each(function(){
                    // and test its normalized href against the url pathname regexp
            if(urlRegExp.test(this.href.replace(/\/$/,''))){
                console.log("this",this);
                $(this).parent().addClass('active');
               
                /*$(this).parent().parent().removeAttr("style");*/
            }
        });
    });
    </script>
     <script type="text/javascript">
 $(document).ready(function() {
    var currentURL = $(location).attr("href");
    var page1= "<?php echo base_url();?>admins/Admin";
    
    if (currentURL === '<?php echo base_url();?>admins/Admin' ) 
    {
       
    $('#dashboardpage').addClass('active');    
    }  
       
});
</script>
    <!-- js placed at the end of the document so the pages load faster -->

    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>

    <script src="<?php echo base_url();?>assets/comingsoon/vendor/jquery/jquery-3.2.1.min.js"></script>
    <script src="<?php echo base_url();?>assets/comingsoon/vendor/bootstrap/js/popper.js"></script>
    <script src="<?php echo base_url();?>assets/comingsoon/vendor/bootstrap/js/bootstrap.min.js"></script>
     <script src="<?php echo base_url();?>assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/assets_front/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="<?php echo base_url();?>assets/js/owl.carousel.js" ></script>
    <script src="<?php echo base_url();?>assets/js/jquery.customSelect.min.js" ></script>
    
     <script src="<?php echo base_url();?>assets/assets_front/summernote/summernote-bs4.min.js"></script>
    
    
   <!-- <script src="<?php echo base_url();?>assets/comingsoon/vendor/select2/select2.min.js"></script>
    <script src="<?php echo base_url();?>assets/comingsoon/vendor/countdowntime/flipclock.min.js"></script>
	<script src="<?php echo base_url();?>assets/comingsoon/vendor/countdowntime/moment.min.js"></script>
	<script src="<?php echo base_url();?>assets/comingsoon/vendor/countdowntime/moment-timezone.min.js"></script>
	<script src="<?php echo base_url();?>assets/comingsoon/vendor/countdowntime/moment-timezone-with-data.min.js"></script>
	<script src="<?php echo base_url();?>assets/comingsoon/vendor/countdowntime/countdowntime.js"></script>
    <script src="<?php echo base_url();?>assets/comingsoon/vendor/tilt/tilt.jquery.min.js"></script>-->
 
    
    
         
         
         
      <script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/assets_front/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/js/respond.min.js" ></script>

    
    <!--right slidebar-->
    <script src="<?php echo base_url();?>assets/js/slidebars.min.js"></script>

  
    <!--dynamic table initialization -->
    <script src="<?php echo base_url();?>assets/js/dynamic_table_init.js"></script>
    
    <!--script for this page-->
    <script src="<?php echo base_url();?>assets/js/sparkline-chart.js"></script>
    <script src="<?php echo base_url();?>assets/js/easy-pie-chart.js"></script>
    <script src="<?php echo base_url();?>assets/js/count.js"></script>
    
    
    
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/fuelux/js/spinner.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-fileupload/bootstrap-fileupload.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-daterangepicker/daterangepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/colorpicker/js/bootstrap-colorpicker.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/jquery-multi-select/js/jquery.multi-select.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/jquery-multi-select/js/jquery.quicksearch.js"></script>
  
 <!-- <script src="<?php echo base_url();?>assets/comingsoon/js/main.js"></script>-->
  
 
   <!--select2-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/assets_front/select2/js/select2.min.js"></script>
  <!--summernote-->
  <script src="<?php echo base_url();?>assets/assets_front/summernote/summernote-bs4.min.js"></script>
   <!--multiselect start + spinner + wysihtml5 scripts-->
  <script src="<?php echo base_url();?>assets/js/advanced-form-components.js"></script>
  <!--pickers script-->
  <script src="<?php echo base_url();?>assets/js/pickers/init-date-picker.js"></script>
  <script src="<?php echo base_url();?>assets/js/pickers/init-datetime-picker.js"></script>
  <script src="<?php echo base_url();?>assets/js/pickers/init-color-picker.js"></script>
<!--bootstrap-switch-->
  <script src="<?php echo base_url();?>assets/assets_front/bootstrap-switch/static/js/bootstrap-switch.js"></script>

  <!--bootstrap-switch-->
  <script src="<?php echo base_url();?>assets/assets_front/switchery/switchery.js"></script>
 
    <!--dropzone -->
    <script src="<?php echo base_url();?>assets/assets_front/dropzone/dropzone.js"></script>
    
     <!--common script for all pages-->
    <script src="<?php echo base_url();?>assets/js/common-scripts.js"></script>
    
      <script src="<?php echo base_url();?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>
     
     
     
  

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true,
			  autoPlay:true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

      $(window).on("resize",function(){
          var owl = $("#owl-demo").data("owlCarousel");
          owl.reinit();
      });

  </script>
  <!-- text editor -->
  <!--<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script>
  tinymce.init({
    selector: 'textarea#editor',
    menubar: false
  });
</script>
<script>
  tinymce.init({
    selector: 'textarea#editor',
    skin: 'bootstrap',
    plugins: 'lists, link, image, media',
    toolbar: 'h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help',
    menubar: false
  });
</script>
<script>
  tinymce.init({
    selector: 'textarea#editor',
    skin: 'bootstrap',
    plugins: 'lists, link, image, media',
    toolbar: 'h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help',
    menubar: false
  });
</script>
<script>
  tinymce.init({
    selector: 'textarea#editor',
    skin: 'bootstrap',
    plugins: 'lists, link, image, media',
    toolbar: 'h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help',
    menubar: false
  });
</script>
<script type="text/javascript">
  tinymce.init({
  selector: "textarea#editor",
  skin: "bootstrap",
  plugins: "lists, link, image, media",
  toolbar:
    "h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help",
  menubar: false,
  setup: editor => {
    // Apply the focus effect
    editor.on("init", () => {
      editor.getContainer().style.transition =
        "border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out";
    });
    editor.on("focus", () => {
      (editor.getContainer().style.boxShadow =
        "0 0 0 .2rem rgba(0, 123, 255, .25)"),
        (editor.getContainer().style.borderColor = "#80bdff");
    });
    editor.on("blur", () => {
      (editor.getContainer().style.boxShadow = ""),
        (editor.getContainer().style.borderColor = "");
    });
  }
});
</script> -->
<!-- text editor end-->


<script>
  
      jQuery(document).ready(function(){

          $('.summernote').summernote({
              height: 200,                 // set editor height

              minHeight: null,             // set minimum height of editor
              maxHeight: null,             // set maximum height of editor

              focus: true                 // set focus to editable area after initializing summernote
          });
      });

  </script>


  </body>
</html>
