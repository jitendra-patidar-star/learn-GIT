<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
	    $this->load->model('api_model/member_model');

    }
    
    public function member_register()
    {
        
        $inputdata= $this->input->post();
        $inputdata['CreditScore'] = '100' ;
        $inputdata['Validtill']= '2029/12/31' ;
        $inputdata['English']= $this->input->post('English');;
        $inputdata['TChinese']= $this->input->post('TChinese'); ;
        $inputdata['SChinese']= $this->input->post('SChinese'); ;
        
        
        if($inputdata['FirstName'] || $inputdata['LastName'] || $inputdata['Phone'] || $inputdata['Email'] ||$inputdata['Retype_Email'] || $inputdata['Password'] || $inputdata['Retype_Password'] || $inputdata['PostCode'])
        {
            $msg = array('status'=>'Failed','msg'=>'Please Fill All Required Fileds');
            echo json_encode($msg);
            
        }
        elseif($inputdata['Email'] != $inputdata['Retype_Email'])
        {
            $msg = array('status'=>'Failed','msg'=>'Email Not Macth');
            echo json_encode($msg);
            
        }
        elseif($inputdata['Password'] != $inputdata['Retype_Password'])
        {
            
            $msg = array('status'=>'Failed','msg'=>'Password Not Macth');
            echo json_encode($msg);
            
        }
        else
        {
            $inputdata['Password'] = md5($inputdata['Password']);
            $this->member_model->member_insert($inputdata);
            $msg = array('status'=>'Success','msg'=>'Registerd Successfully');
            echo json_encode($msg);
            
        }
        
    }
    
    public function member_auth()
    {
        $email    = $this->input->post('email');
        $password = $this->input->post('password');
        $phone = $this->input->post('phone');
        
        if($email !='' || $password!=''){
            
            $auth =  $this->member_model->member_auth_data( $email , $password );  
        
                if($auth->num_rows() > 0){
                     
                        $logindata  = $auth->row_array();
                        $userid=     $logindata['MemberID'];
                        $email = $logindata['Email'];
                        
                        //$sesdata = array('id'=>$id,'email'=> $email,'logged_in' => TRUE);
                        //$this->session->set_userdata($sesdata);
                        //redirect('Admin/dashboard');
        	        
        	        $datas = array('status'=>'Success','msg'=>'Login Successfully','user_id'=>$userid);
                    echo json_encode($datas);
                   
        	    }else{
        	        
        	        $datas = array('status'=>'Failed','msg'=>'Invalid Login Details!!');
                    echo json_encode($datas);
                    
        	    }
            
        }elseif($phone !='' || $password!=''){
            
            $auth =  $this->member_model->member_auth_data_with_phone( $phone , $password );  
        
                if($auth->num_rows() > 0){
                     
                        $logindata  = $auth->row_array();
                        $userid=     $logindata['MemberID'];
                        $phone = $logindata['Phone'];
                        
                        //$sesdata = array('id'=>$id,'email'=> $email,'logged_in' => TRUE);
                        //$this->session->set_userdata($sesdata);
                        //redirect('Admin/dashboard');
        	        
        	        $datas = array('status'=>'Success','msg'=>'Login Successfully','user_id'=>$userid);
                    echo json_encode($datas);
                   
        	    }else{
        	        
        	        $datas = array('status'=>'Failed','msg'=>'Invalid Login Details!!');
                    echo json_encode($datas);
                    
        	    }
        	    
        }else{
            
            $datas = array('status'=>'Failed','msg'=>'Please Fill Both Fileds');
            echo json_encode($datas);
        }
      
      
    }
    
    public function reset_password_token()
    {
        
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        
        if($email != ''){
            
            $length = 8;
            $str = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
              
            $resettoken = substr(str_shuffle($str), 0, $length);
            
            $this->member_model->insert_reset_token($email,$resettoken);

        }elseif($phone != ''){
            
        }
        
    }
    
    
    /*public function reset_password()
    {
        $inputdata = $this->input->post();
        
        if($inputdata['Phone'] =='' || $inputdata['Email'] =='' || $inputdata['Phone'] =='' || $inputdata['Phone'] =='' || $inputdata['Phone'] =='')
        {
            
        }
        
    }*/
}