<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_model extends CI_Model {

   	public function __construct()
	{
		parent::__construct();
	}
	
	public function member_insert($data)
	{
	    $this->db->insert('Member',$data);
	}
	
	public function member_auth_data($email,$password)
	{
	 
	 $q =  $this->db->select('Email,Phone,Password')
	                ->from('Member')
	                ->where(array('Email'=>$email,'Password'=>md5($password)))
	                ->get();
	 return $q;
	}
	
	public function member_auth_data_with_phone($phone,$password)
	{
	 
	 $q =  $this->db->select('Email,Phone,Password')
	                ->from('Member')
	                ->where(array('Phone'=>$phone,'Password'=>md5($password)))
	                ->get();
	 return $q;
	}
	
	public function insert_reset_token($email,$resettoken)
	{
	    $resetdata = array('ResetPasswordToken',$resettoken);
	    $q =   $this->db->where(array('Email'=>$email))
	                    ->update('Member',$resetdata);
	}
	
}